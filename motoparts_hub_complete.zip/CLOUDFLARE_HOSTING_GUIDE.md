# MotoParts Hub — Cloudflare Hosting Guide

This is a static multi-page HTML/CSS/JavaScript website. It can be deployed with Cloudflare Pages Direct Upload.

## Option 1 — Easiest: Cloudflare Dashboard upload

1. Create/sign in to your Cloudflare account.
2. Open **Workers & Pages**.
3. Choose **Create application** / **Get started** and choose **Drag and drop your files**.
4. Create a project name, for example:
   `motoparts-hub`
5. Upload the ZIP file you received from ChatGPT.
6. Click **Deploy site**.
7. Cloudflare will give you a URL similar to:
   `https://motoparts-hub.pages.dev`

IMPORTANT:
- The ZIP must contain `index.html` at its top level. This package does.
- Do not upload the ZIP inside another ZIP.
- Do not rename `index.html`.

## Option 2 — Upload an extracted folder

If Cloudflare asks for a folder instead of the ZIP, extract this ZIP first and upload the extracted website folder.

The main files are:
- index.html
- shop.html
- product.html
- cart.html
- checkout.html
- about.html
- contact.html
- owner-login.html
- admin.html
- style.css
- app.js

## Add your own domain

After deployment:

1. Open **Workers & Pages** in Cloudflare.
2. Select your MotoParts Hub project.
3. Open **Custom domains**.
4. Select **Set up a custom domain**.
5. Enter your domain, for example:
   `www.yourdomain.com`
6. Follow Cloudflare's DNS instructions.

For an apex domain such as `yourdomain.com`, Cloudflare requires the domain to be a zone in the Cloudflare account and its nameservers configured for Cloudflare.

For a subdomain such as `shop.yourdomain.com`, Cloudflare uses a CNAME setup.

## Important before going live

This package is a front-end prototype. The owner login and dashboard are NOT real security yet.

Before using it for real customer orders:

1. Add a real server-side owner authentication system.
2. Store products and orders in a real database.
3. Never put the real owner password inside HTML or JavaScript.
4. Connect checkout to your preferred order/payment system.
5. Replace the sample motorcycle images with your actual product photos.
6. Replace demo phone/WhatsApp information with your business contact.
7. Replace sample prices and fitment information with your actual inventory.
8. Test the website on a phone before advertising it.

The public website intentionally has no customer seller-registration feature. Only the store owner should be able to manage inventory.

## Updating the website

For simple static changes, make the changes locally and deploy a new version from the Cloudflare Pages project.

For a larger production system, consider connecting the project to a Git repository so changes can be deployed automatically.

## Current structure

MotoParts Hub
├── index.html
├── shop.html
├── product.html
├── cart.html
├── checkout.html
├── about.html
├── contact.html
├── owner-login.html
├── admin.html
├── style.css
├── app.js
├── README.md
└── CLOUDFLARE_HOSTING_GUIDE.md
