# MotoParts Hub v2 — Multi-page website
Pages: Home, Shop, Product Details, Cart, Checkout, About, Contact, Owner Login and private Owner Dashboard.
The website contains 30 starter products across KTM, Yamaha, Ducati, Suzuki, Kawasaki, Honda, BMW, Harley-Davidson, Aprilia and Triumph.
This is a front-end prototype. For production, add server-side authentication, database storage, real product photos, payment/order processing and your business contact details.
